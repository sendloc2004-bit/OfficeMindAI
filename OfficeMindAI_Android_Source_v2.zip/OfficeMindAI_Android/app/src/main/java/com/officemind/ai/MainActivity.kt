package com.officemind.ai

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.ByteArrayOutputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : Activity() {
    private lateinit var prompt: EditText
    private lateinit var status: TextView
    private var pendingBytes: ByteArray? = null
    private var pendingMime: String = "application/octet-stream"
    private var pendingName: String = "OfficeMind-output.bin"
    private val createFileRequest = 4201

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 20, 22, 18)
            setBackgroundColor(0xFFF4F7F6.toInt())
        }

        val title = TextView(this).apply {
            text = "OfficeMind AI"
            textSize = 27f
            setTextColor(0xFF123E37.toInt())
            gravity = Gravity.CENTER
        }
        outer.addView(title, matchWrap())

        val subtitle = TextView(this).apply {
            text = "مساعد محلي لإنشاء ملفات Excel وWord — نسخة أولية تعمل دون إنترنت"
            textSize = 14f
            setTextColor(0xFF52635F.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 18)
        }
        outer.addView(subtitle, matchWrap())

        prompt = EditText(this).apply {
            hint = "اكتب طلبك أو ألصق البيانات هنا...\n\nمثال Excel:\nالمنتج,الكمية,المعيب\nبسكويت,120,4\nعصير,200,7"
            minLines = 7
            gravity = Gravity.TOP or Gravity.START
            textSize = 15f
            setPadding(14, 12, 14, 12)
            setBackgroundColor(0xFFFFFFFF.toInt())
        }
        outer.addView(prompt, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val excel = Button(this).apply {
            text = "إنشاء Excel"
            setOnClickListener { createExcel() }
        }
        val word = Button(this).apply {
            text = "إنشاء Word"
            setOnClickListener { createWord() }
        }
        row1.addView(excel, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row1.addView(word, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        outer.addView(row1, matchWrap())

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val sample = Button(this).apply {
            text = "بيانات تجريبية"
            setOnClickListener {
                prompt.setText(
                    "المنتج,الكمية المنتجة,الكمية المعيبة\n" +
                    "بسكويت سادة,1200,24\n" +
                    "بسكويت شوكولاتة,950,19\n" +
                    "عصير برتقال,700,21\n" +
                    "كيك,540,8"
                )
                status.text = "تم إدخال بيانات تجريبية. اختر إنشاء Excel أو Word."
            }
        }
        val clear = Button(this).apply {
            text = "مسح"
            setOnClickListener { prompt.setText(""); status.text = "جاهز." }
        }
        row2.addView(sample, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row2.addView(clear, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        outer.addView(row2, matchWrap())

        status = TextView(this).apply {
            text = "جاهز. لا يتصل التطبيق بالإنترنت ولا يرسل بياناتك لأي جهة."
            textSize = 13f
            setTextColor(0xFF31534C.toInt())
            setPadding(4, 10, 4, 4)
        }
        outer.addView(status, matchWrap())

        val scroll = ScrollView(this)
        scroll.addView(outer)
        setContentView(scroll)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun createExcel() {
        val raw = prompt.text.toString().trim()
        val rows = parseRows(raw)
        val data = if (rows.isEmpty()) defaultProductionRows() else rows
        val bytes = XlsxWriter.create(data)
        saveWithPicker(bytes,
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            "OfficeMind-Report.xlsx")
    }

    private fun createWord() {
        val raw = prompt.text.toString().trim()
        if (raw.isEmpty()) {
            Toast.makeText(this, "اكتب النص الذي تريد وضعه في Word أولًا.", Toast.LENGTH_LONG).show()
            return
        }
        val bytes = DocxWriter.create(raw)
        saveWithPicker(bytes,
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            "OfficeMind-Document.docx")
    }

    private fun parseRows(raw: String): List<List<String>> {
        if (raw.isBlank()) return emptyList()
        val lines = raw.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.isEmpty()) return emptyList()
        return lines.map { line ->
            when {
                line.contains('\t') -> line.split('\t').map { it.trim() }
                line.contains('|') -> line.trim('|').split('|').map { it.trim() }
                line.contains(';') -> line.split(';').map { it.trim() }
                else -> line.split(',').map { it.trim() }
            }
        }
    }

    private fun defaultProductionRows() = listOf(
        listOf("المنتج", "الكمية المنتجة", "الكمية المعيبة", "الكمية السليمة", "نسبة العيوب"),
        listOf("بسكويت سادة", "1200", "24", "1176", "2%"),
        listOf("بسكويت شوكولاتة", "950", "19", "931", "2%"),
        listOf("عصير برتقال", "700", "21", "679", "3%"),
        listOf("كيك", "540", "8", "532", "1.48%")
    )

    private fun saveWithPicker(bytes: ByteArray, mime: String, name: String) {
        pendingBytes = bytes
        pendingMime = mime
        pendingName = name
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = mime
            putExtra(Intent.EXTRA_TITLE, name)
        }
        startActivityForResult(intent, createFileRequest)
    }

    @Deprecated("Legacy activity result API is used for broad Android compatibility.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == createFileRequest && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            try {
                val bytes = pendingBytes ?: return
                contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                status.text = "تم إنشاء الملف وحفظه بنجاح: $pendingName"
                Toast.makeText(this, "تم حفظ الملف بنجاح", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
                status.text = "تعذر حفظ الملف: ${e.message ?: "خطأ غير معروف"}"
            } finally {
                pendingBytes = null
            }
        }
    }
}

private object XlsxWriter {
    fun create(rows: List<List<String>>): ByteArray {
        val safeRows = if (rows.isEmpty()) listOf(listOf("لا توجد بيانات")) else rows
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            entry(zip, "[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>""")
            entry(zip, "_rels/.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>""")
            entry(zip, "xl/workbook.xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets><sheet name="البيانات" sheetId="1" r:id="rId1"/></sheets></workbook>""")
            entry(zip, "xl/_rels/workbook.xml.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>""")
            entry(zip, "xl/styles.xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<fonts count="2"><font><sz val="11"/><name val="Arial"/></font><font><b/><sz val="11"/><color rgb="FFFFFFFF"/><name val="Arial"/></font></fonts>
<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF176B5B"/><bgColor indexed="64"/></patternFill></fill></fills>
<borders count="2"><border/><border><left style="thin"><color rgb="FFD9E2DF"/></left><right style="thin"><color rgb="FFD9E2DF"/></right><top style="thin"><color rgb="FFD9E2DF"/></top><bottom style="thin"><color rgb="FFD9E2DF"/></bottom></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="1" borderId="1" xfId="0" applyAlignment="1"><alignment horizontal="center" vertical="center" wrapText="1"/></xf><xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf></cellXfs>
</styleSheet>""")
            val sheet = StringBuilder()
            sheet.append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>
<sheetFormatPr defaultRowHeight="22"/><sheetData>""")
            for ((rowIndex, row) in safeRows.withIndex()) {
                val rowNumber = rowIndex + 1
                sheet.append("<row r=\"$rowNumber\">")
                for ((columnIndex, value) in row.withIndex()) {
                    val reference = "${colName(columnIndex + 1)}$rowNumber"
                    val style = if (rowNumber == 1) 1 else 2
                    val escaped = xmlEscape(value)
                    if (rowNumber > 1 && isNumeric(value)) {
                        val numericValue = value.replace(",", "")
                        sheet.append("<c r=\"$reference\" s=\"$style\"><v>$numericValue</v></c>")
                    } else {
                        sheet.append("<c r=\"$reference\" s=\"$style\" t=\"inlineStr\"><is><t xml:space=\"preserve\">$escaped</t></is></c>")
                    }
                }
                sheet.append("</row>")
            }
            val lastColumn = colName(safeRows.maxOf { it.size })
            sheet.append("</sheetData><autoFilter ref=\"A1:${lastColumn}${safeRows.size}\"/></worksheet>")
            entry(zip, "xl/worksheets/sheet1.xml", sheet.toString())
        }
        return out.toByteArray()
    }
}

private fun colName(n: Int): String {
    var x = n
    var result = ""
    while (x > 0) {
        val r = (x - 1) % 26
        result = ('A'.code + r).toChar() + result
        x = (x - 1) / 26
    }
    return result
}

private fun isNumeric(value: String): Boolean =
    value.trim().replace(",", "").toDoubleOrNull() != null && value.isNotBlank()

private fun xmlEscape(s: String): String = s.replace("&", "&amp;")
    .replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")

private fun entry(zipOut: ZipOutputStream, name: String, content: String) {
    zipOut.putNextEntry(ZipEntry(name))
    zipOut.write(content.toByteArray(Charsets.UTF_8))
    zipOut.closeEntry()
}
